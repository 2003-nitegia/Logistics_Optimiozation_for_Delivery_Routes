-- a)-
SELECT * FROM warehouses ORDER BY average_processing_time_min DESC LIMIT 3;

-- b)-
-- select *,count(*) from shipmenttracking group by Order_ID;
-- select *,count(*) from orders group by Warehouse_ID;
SELECT w.warehouse_id,w.warehouse_name,COUNT(o.order_id) AS Total_shipment,
SUM(CASE WHEN o.actual_delivery_date - o.expected_delivery_date > 0 THEN 1 ELSE 0 END) AS delayed_shipment
FROM warehouses w
LEFT JOIN orders o ON w.Warehouse_ID = o.Warehouse_ID
GROUP BY w.Warehouse_ID;

-- c)-
with bottleneck as (
select warehouse_id,warehouse_name,city,average_processing_Time_min,avg(average_processing_time_min) over() as globalavg from warehouses
)
select * from bottleneck where average_processing_time_min > globalavg;

-- d)-
select w.warehouse_id,w.warehouse_name, 
(sum(case when o.actual_delivery_date - o.expected_delivery_date = 0 then 1 else 0 end) / count(o.order_id) ) * 100 as on_time_percent , 
rank() over( order by ( sum(case when o.actual_delivery_date - o.expected_delivery_date = 0 then 1 else 0 end) / count(o.order_id) ) * 100)  as on_time_Rank 
from warehouses w 
left join orders o on w.Warehouse_ID = o.Warehouse_ID 
group by w.Warehouse_ID;

