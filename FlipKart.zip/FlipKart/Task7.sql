-- a)-
SELECT r.start_location as Region, round(avg(o.actual_delivery_date - o.expected_delivery_date)) AS average_delay_days
FROM routes r inner join orders o on r.Route_ID = o.Route_ID group by r.Start_Location ;


-- b)-
select sum(case when (actual_delivery_date - expected_delivery_date) = 0 then 1 else 0 end) as On_time_delivery ,
 count(*) as total_deliveries, 
 (sum(case when (actual_delivery_date - expected_delivery_date) = 0 then 1 else 0 end) / count(*)) * 100 as On_time_delivery_percent
from orders;


-- c)-
select route_id, round(avg(traffic_delay_min)) as Average_Traffic_Delay
from routes group by Route_ID;