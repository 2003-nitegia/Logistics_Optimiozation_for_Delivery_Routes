-- a)-
SELECT * FROM orders;
SELECT *, actual_delivery_date - expected_delivery_date AS delay_days FROM orders;

-- b)-
SELECT * FROM routes;
SELECT r.route_id,r.start_location,r.end_location,AVG(o.actual_delivery_date - o.expected_delivery_date) AS average_delay_days
FROM orders o
JOIN routes r ON o.route_id = r.route_id
GROUP BY r.route_id
ORDER BY average_delay_days DESC
LIMIT 10;

-- c)-
SELECT * FROM orders;
select order_id, warehouse_id,actual_delivery_date - expected_delivery_date as delay_days ,
rank() over (partition by warehouse_id order by actual_delivery_date - expected_delivery_date desc ) as ranks_wareshouse
from orders;
