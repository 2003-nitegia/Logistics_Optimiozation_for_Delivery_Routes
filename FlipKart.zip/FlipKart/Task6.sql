-- a)-
SELECT *,MAX(Checkpoint_Time) AS last_time,MAX(checkpoint) AS last_checkpoint
FROM shipmenttracking
GROUP BY Order_ID
ORDER BY order_id;

-- b)-
with delay as(
select delay_reason, count(*) as no_of_orders from shipmenttracking group by Delay_Reason
)
select * from delay order by no_of_orders desc limit 1;

-- c)-
with checkpoint_delay as (
select order_id,Checkpoint,count(Checkpoint) as delayed_checkpoint from shipmenttracking where Delay_Reason <> 'none' group by order_id  order by Order_ID
)
select * from checkpoint_delay where delayed_checkpoint > 2;

