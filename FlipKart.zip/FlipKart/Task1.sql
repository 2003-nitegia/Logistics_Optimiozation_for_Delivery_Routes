-- a)-
SELECT * FROM orders;
select * , row_number() over (order by order_id ) as Unique_no  from orders;
SELECT * FROM routes;
select * , row_number() over (order by route_id ) as Unique_no  from routes;
SELECT * FROM deliveryagents;
select * , row_number() over (order by agent_id ) as Unique_no  from deliveryagents;
SELECT * FROM shipmenttracking;
select * , row_number() over (order by tracking_id ) as Unique_no  from shipmenttracking;
SELECT * FROM warehouses;
select * , row_number() over (order by warehouse_id ) as Unique_no  from warehouses;

-- b)-
SELECT * FROM routes;
-- There is no NULL values in the traffic_delay_min Column .   !!!!

-- c)-
SELECT * FROM orders;
alter table orders
modify column Order_date date ;
alter table orders
modify column Expected_delivery_date date ;
alter table orders
modify column actual_delivery_date date ;

-- d) 
SELECT * FROM orders;
SELECT *,
    CASE
        WHEN actual_delivery_date < order_date THEN 'flagged'
        ELSE 'no Flagged'
    END AS flagged_dates
FROM
    orders;