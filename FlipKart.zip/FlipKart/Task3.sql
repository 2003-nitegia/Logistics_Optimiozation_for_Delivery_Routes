-- a)-
SELECT r.route_id,r.distance_km,AVG(o.actual_delivery_date - o.Order_date) AS avg_delay_days,AVG(r.traffic_delay_min) AS avg_traffic_delay
FROM routes r
LEFT JOIN orders o ON r.Route_ID = o.Route_ID
GROUP BY r.Route_ID;

SELECT route_id,Distance_KM,Average_Travel_Time_Min,(Distance_KM / Average_Travel_Time_Min) AS Distance_to_time_ratio
FROM routes;

-- b)-
SELECT route_id,Distance_KM,Average_Travel_Time_Min,(Distance_KM / Average_Travel_Time_Min) AS Distance_to_time_ratio
FROM routes
ORDER BY distance_to_time_ratio
LIMIT 3;

-- c)-
with delay as(
select r.route_id,r.Start_Location,r.End_Location ,( sum(case when o.actual_delivery_date - o.expected_delivery_date > 0 then 1 else 0 end) / count(o.order_id) ) * 100 as Delay_percent
from routes r
left join orders o on r.Route_ID = o.Route_ID  group by r.Route_ID
)
select * from delay where delay_percent > 20;

-- d)-
-- Recommend potential routes for optimization (rule-of-thumb suggestions):

-- Prioritize routes with high delayed_pct and low eff_ratio (bad efficiency + many delays).

-- Also consider routes with large avg_traffic_delay_min and short distances (suggest route re-timing or alternate local routes).