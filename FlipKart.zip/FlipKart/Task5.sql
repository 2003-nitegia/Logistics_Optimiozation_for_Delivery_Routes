-- a)-
select Agent_id,Agent_name,Route_id,On_time_delivery_percentage,
rank() over(partition by route_id order by on_time_delivery_percentage desc) as Ranking_over_route
from deliveryagents;

-- b)-
SELECT * FROM deliveryagents
WHERE On_Time_Delivery_Percentage < 80;

-- c)-
with top5 as (
select agent_id,agent_name,avg_speed_kmph from deliveryagents order by Avg_Speed_KMPH limit 5),
bottom5 as (
select agent_id,agent_name,avg_speed_kmph from deliveryagents order by Avg_Speed_KMPH desc limit 5
)
select avg(t.avg_speed_kmph) as average_of_top5, avg(b.avg_speed_kmph) as average_of_bottom5 from top5 t join bottom5 b ;

-- d)-
